@echo off
@chcp 65001 >nul 2>&1
@setlocal enabledelayedexpansion

:: ========== ALL ZAPRET v1.0.1 ==========
:: Универсальный обход блокировок DPI
:: Автор: @EvilRW

:: ========== АВТОМАТИЧЕСКИЙ ЗАПУСК ОТ АДМИНИСТРАТОРА ==========
>nul 2>&1 "%SYSTEMROOT%\system32\cacls.exe" "%SYSTEMROOT%\system32\config\system"
if '%errorlevel%' NEQ '0' (
    echo Запрос прав администратора...
    timeout /t 1 /nobreak >nul
    powershell -NoProfile -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

:: ========== НАСТРОЙКИ ИНТЕРФЕЙСА ==========
title ALL Zapret v1.0.1
mode con cols=100 lines=40
color 07

:: ========== ПЕРЕМЕННЫЕ ==========
set "BIN=%~dp0bin\"
set "LISTS=%~dp0lists\"
set "UTILS=%~dp0utils\"
set "LOCAL_VERSION=1.0.1"
set "PROGRAM_NAME=ALL Zapret"
set "LAST_MSG="

:: ========== ЗАГРУЗКА НАСТРОЕК ==========
call :load_settings

:: ========== ФУНКЦИЯ ОЧИСТКИ С СООБЩЕНИЕМ ==========
:clear_with_msg
cls
echo.
echo ╔══════════════════════════════════════════════════════════════════════════╗
echo ║                         ALL-ZAPRET %LOCAL_VERSION%                               ║
echo ║                         youtube: @EvilRW                                      ║
echo ╠══════════════════════════════════════════════════════════════════════════╣
echo ║                                                                          ║
echo ║  !LAST_MSG!                                             ║
echo ║                                                                          ║
echo ╚══════════════════════════════════════════════════════════════════════════╝
echo.
timeout /t 2 /nobreak >nul
goto menu

:: ========== ГЛАВНОЕ МЕНЮ ==========
:menu
cls
echo.
echo ╔══════════════════════════════════════════════════════════════════════════╗
echo ║                         ALL-ZAPRET %LOCAL_VERSION%                               ║
echo ║                         youtube: @EvilRW                                      ║
echo ╠══════════════════════════════════════════════════════════════════════════╣
echo ║                                                                          ║
echo ║  [1] 🚀 ЗАПУСТИТЬ ОБХОД                   [9]  🌐 IPSET ФИЛЬТР           ║
echo ║  [2] ⚙️ УПРАВЛЕНИЕ СЕРВИСОМ                [10] 🔄 АВТО-ОБНОВЛЕНИЕ       ║
echo ║  [3] 📋 ДОБАВИТЬ СВОЙ ДОМЕН                [11] 🎮 ИГРОВОЙ РЕЖИМ         ║
echo ║  [4] 🔧 ДИАГНОСТИКА                        [12] 🌍 РЕЖИМ DNS             ║
echo ║  [5] 🧪 ТЕСТЫ                              [13] 🔒 SSL/TLS НАСТРОЙКИ     ║
echo ║  [6] 📥 ОБНОВИТЬ СПИСКИ                    [14] ⚡ РЕЖИМ ПРОИЗВОДИТЕЛЬНОСТИ║
echo ║  [7] 🗑️ ОЧИСТИТЬ КЭШ                       [15] 🔄 АВТОЗАПУСК ЗАПРЕТА    ║
echo ║  [8] 📊 СТАТИСТИКА                         [0]  ❌ ВЫХОД                 ║
echo ║                                                                          ║
echo ╠══════════════════════════════════════════════════════════════════════════╣
echo ║  ТЕКУЩИЕ НАСТРОЙКИ:                                                     ║
echo ║  Игровой фильтр: !GAME_FILTER_STATUS!    IPSet: !IPSET_STATUS!          ║
echo ║  Автообновление: !UPDATE_STATUS!         Автозапуск: !AUTORUN_STATUS!   ║
echo ║  DNS режим: !DNS_MODE!                   SSL/TLS: !SSL_MODE!            ║
echo ║  Производительность: !PERF_MODE!                                        ║
echo ╚══════════════════════════════════════════════════════════════════════════╝
echo.
set /p choice="   Выберите опцию (0-15): "

if "%choice%"=="1" goto run_bypass
if "%choice%"=="2" goto service_menu
if "%choice%"=="3" goto add_domain
if "%choice%"=="4" goto diagnostics
if "%choice%"=="5" goto run_tests
if "%choice%"=="6" goto update_lists
if "%choice%"=="7" goto clear_cache
if "%choice%"=="8" goto statistics
if "%choice%"=="9" goto ipset_settings
if "%choice%"=="10" goto auto_update_settings
if "%choice%"=="11" goto game_mode_settings
if "%choice%"=="12" goto dns_settings
if "%choice%"=="13" goto ssl_settings
if "%choice%"=="14" goto performance_settings
if "%choice%"=="15" goto autorun_settings
if "%choice%"=="0" exit /b
goto menu

:: ========== ЗАПУСК ОБХОДА ==========
:run_bypass
cls
echo ╔══════════════════════════════════════════════════════════════════════════╗
echo ║                         🚀 ЗАПУСК ОБХОДА 🚀                              ║
echo ╚══════════════════════════════════════════════════════════════════════════╝
echo.

:: Проверка файлов
if not exist "%BIN%winws.exe" (
    set "LAST_MSG=❌ ОШИБКА: winws.exe не найден!"
    goto clear_with_msg
)

:: Остановка старых процессов
taskkill /F /IM winws.exe >nul 2>&1
timeout /t 2 /nobreak >nul

:: Сбор параметров
set "TCP_PORTS=80,443,2053,2083,2087,2096,8443"
set "UDP_PORTS=443,19294-19344,50000-50100"

if "!GAME_MODE!"=="1" (
    set "TCP_PORTS=!TCP_PORTS!,1024-65535"
    set "UDP_PORTS=!UDP_PORTS!,1024-65535"
    set "GAME_PARAM=--dpi-desync-any-protocol=1"
)

:: Запуск
cd /d "%BIN%"

start "ALL Zapret" /min "%BIN%winws.exe" ^
--wf-tcp=!TCP_PORTS! ^
--wf-udp=!UDP_PORTS! ^
--filter-udp=443 --hostlist="%LISTS%list-general.txt" --hostlist="%LISTS%list-general-user.txt" --hostlist-exclude="%LISTS%list-exclude.txt" --hostlist-exclude="%LISTS%list-exclude-user.txt" --ipset-exclude="%LISTS%ipset-exclude.txt" --ipset-exclude="%LISTS%ipset-exclude-user.txt" --dpi-desync=fake --dpi-desync-repeats=11 --dpi-desync-fake-quic="%BIN%quic_initial_www_google_com.bin" --new ^
--filter-udp=19294-19344,50000-50100 --filter-l7=discord,stun --dpi-desync=fake --dpi-desync-repeats=6 --new ^
--filter-tcp=2053,2083,2087,2096,8443 --hostlist-domains=discord.media --dpi-desync=fake,multisplit --dpi-desync-split-seqovl=681 --dpi-desync-split-pos=1 --dpi-desync-fooling=ts --dpi-desync-repeats=8 --dpi-desync-split-seqovl-pattern="%BIN%tls_clienthello_www_google_com.bin" --dpi-desync-fake-tls="%BIN%tls_clienthello_www_google_com.bin" --new ^
--filter-tcp=443 --hostlist="%LISTS%list-google.txt" --ip-id=zero --dpi-desync=fake,multisplit --dpi-desync-split-seqovl=681 --dpi-desync-split-pos=1 --dpi-desync-fooling=ts --dpi-desync-repeats=8 --dpi-desync-split-seqovl-pattern="%BIN%tls_clienthello_www_google_com.bin" --dpi-desync-fake-tls="%BIN%tls_clienthello_www_google_com.bin" --new ^
--filter-tcp=80,443 --hostlist="%LISTS%list-general.txt" --hostlist="%LISTS%list-general-user.txt" --hostlist-exclude="%LISTS%list-exclude.txt" --hostlist-exclude="%LISTS%list-exclude-user.txt" --ipset-exclude="%LISTS%ipset-exclude.txt" --ipset-exclude="%LISTS%ipset-exclude-user.txt" --dpi-desync=fake,multisplit --dpi-desync-split-seqovl=664 --dpi-desync-split-pos=1 --dpi-desync-fooling=ts --dpi-desync-repeats=8 --dpi-desync-split-seqovl-pattern="%BIN%tls_clienthello_max_ru.bin" --dpi-desync-fake-tls="%BIN%stun.bin" --dpi-desync-fake-tls="%BIN%tls_clienthello_max_ru.bin" --dpi-desync-fake-http="%BIN%tls_clienthello_max_ru.bin" --new ^
--filter-udp=443 --ipset="%LISTS%ipset-all.txt" --hostlist-exclude="%LISTS%list-exclude.txt" --hostlist-exclude="%LISTS%list-exclude-user.txt" --ipset-exclude="%LISTS%ipset-exclude.txt" --ipset-exclude="%LISTS%ipset-exclude-user.txt" --dpi-desync=fake --dpi-desync-repeats=11 --dpi-desync-fake-quic="%BIN%quic_initial_www_google_com.bin" --new ^
--filter-tcp=80,443,8443 --ipset="%LISTS%ipset-all.txt" --hostlist-exclude="%LISTS%list-exclude.txt" --hostlist-exclude="%LISTS%list-exclude-user.txt" --ipset-exclude="%LISTS%ipset-exclude.txt" --ipset-exclude="%LISTS%ipset-exclude-user.txt" --dpi-desync=fake,multisplit --dpi-desync-split-seqovl=664 --dpi-desync-split-pos=1 --dpi-desync-fooling=ts --dpi-desync-repeats=8 --dpi-desync-split-seqovl-pattern="%BIN%tls_clienthello_max_ru.bin" --dpi-desync-fake-tls="%BIN%stun.bin" --dpi-desync-fake-tls="%BIN%tls_clienthello_max_ru.bin" --dpi-desync-fake-http="%BIN%tls_clienthello_max_ru.bin" --new ^
--filter-tcp=1024-65535 --ipset="%LISTS%ipset-all.txt" --ipset-exclude="%LISTS%ipset-exclude.txt" --ipset-exclude="%LISTS%ipset-exclude-user.txt" !GAME_PARAM! --dpi-desync=fake,multisplit --dpi-desync-cutoff=n4 --dpi-desync-split-seqovl=664 --dpi-desync-split-pos=1 --dpi-desync-fooling=ts --dpi-desync-repeats=8 --dpi-desync-split-seqovl-pattern="%BIN%tls_clienthello_max_ru.bin" --dpi-desync-fake-tls="%BIN%stun.bin" --dpi-desync-fake-tls="%BIN%tls_clienthello_max_ru.bin" --dpi-desync-fake-http="%BIN%tls_clienthello_max_ru.bin" --new ^
--filter-udp=1024-65535 --ipset="%LISTS%ipset-all.txt" --ipset-exclude="%LISTS%ipset-exclude.txt" --ipset-exclude="%LISTS%ipset-exclude-user.txt" !GAME_PARAM! --dpi-desync=fake --dpi-desync-repeats=10 --dpi-desync-fake-unknown-udp="%BIN%quic_initial_www_google_com.bin" --dpi-desync-cutoff=n4

timeout /t 3 /nobreak >nul
tasklist | find /I "winws.exe" >nul

if !errorlevel! equ 0 (
    set "LAST_MSG=✅ ОБХОД УСПЕШНО ЗАПУЩЕН! PID: !PID!"
) else (
    set "LAST_MSG=❌ ОШИБКА ЗАПУСКА! Проверьте файлы в папке bin/"
)
goto clear_with_msg

:: ========== УПРАВЛЕНИЕ СЕРВИСОМ ==========
:service_menu
cls
echo ╔══════════════════════════════════════════════════════════════════════════╗
echo ║                         ⚙️ УПРАВЛЕНИЕ СЕРВИСОМ ⚙️                       ║
echo ╚══════════════════════════════════════════════════════════════════════════╝
echo.
echo   [1] 📦 УСТАНОВИТЬ СЕРВИС
echo   [2] 🗑️ УДАЛИТЬ СЕРВИС
echo   [3] 🔍 СТАТУС СЕРВИСА
echo   [4] 🔙 НАЗАД
echo.
set /p svc_choice="   Выберите опцию: "

if "%svc_choice%"=="1" (
    if exist "%~dp0service.bat" (
        call "%~dp0service.bat" admin
        set "LAST_MSG=✅ Сервис установлен"
    ) else (
        set "LAST_MSG=❌ service.bat не найден"
    )
    goto clear_with_msg
)
if "%svc_choice%"=="2" (
    sc stop zapret >nul 2>&1
    sc delete zapret >nul 2>&1
    set "LAST_MSG=✅ Сервис удален"
    goto clear_with_msg
)
if "%svc_choice%"=="3" (
    sc query zapret | find "STATE" > tmp.txt
    set /p status=<tmp.txt
    del tmp.txt
    set "LAST_MSG=📊 Статус: !status!"
    goto clear_with_msg
)
if "%svc_choice%"=="4" goto menu
goto service_menu

:: ========== ДОБАВЛЕНИЕ ДОМЕНА ==========
:add_domain
cls
echo ╔══════════════════════════════════════════════════════════════════════════╗
echo ║                         📋 ДОБАВЛЕНИЕ ДОМЕНА 📋                          ║
echo ╚══════════════════════════════════════════════════════════════════════════╝
echo.
set /p newdomain="   Введите домен (например: example.com): "

if "!newdomain!"=="" (
    set "LAST_MSG=❌ Домен не введен"
    goto clear_with_msg
)

echo !newdomain! >> "%LISTS%list-general-user.txt"
set "LAST_MSG=✅ Домен !newdomain! добавлен в list-general-user.txt"
goto clear_with_msg

:: ========== ДИАГНОСТИКА ==========
:diagnostics
cls
echo ╔══════════════════════════════════════════════════════════════════════════╗
echo ║                         🔧 ДИАГНОСТИКА 🔧                                ║
echo ╚══════════════════════════════════════════════════════════════════════════╝
echo.

set "DIAG_MSG="

:: Проверка 1: Права администратора
net session >nul 2>&1
if !errorlevel! equ 0 (set "DIAG_MSG=!DIAG_MSG! ✅ Права администратора: Есть\n") else (set "DIAG_MSG=!DIAG_MSG! ❌ Права администратора: Нет\n")

:: Проверка 2: Архитектура
if "%PROCESSOR_ARCHITECTURE%"=="AMD64" (set "DIAG_MSG=!DIAG_MSG! ✅ Архитектура: 64-bit\n") else (set "DIAG_MSG=!DIAG_MSG! ❌ Архитектура: 32-bit (не поддерживается)\n")

:: Проверка 3: winws.exe
if exist "%BIN%winws.exe" (set "DIAG_MSG=!DIAG_MSG! ✅ winws.exe: Найден\n") else (set "DIAG_MSG=!DIAG_MSG! ❌ winws.exe: Не найден\n")

:: Проверка 4: Статус процесса
tasklist | find /I "winws.exe" >nul
if !errorlevel! equ 0 (set "DIAG_MSG=!DIAG_MSG! ✅ winws.exe: Запущен\n") else (set "DIAG_MSG=!DIAG_MSG! ⚠️ winws.exe: Не запущен\n")

:: Проверка 5: Списки
if exist "%LISTS%list-general.txt" (set "DIAG_MSG=!DIAG_MSG! ✅ general list: Есть\n") else (set "DIAG_MSG=!DIAG_MSG! ⚠️ general list: Нет\n")
if exist "%LISTS%list-google.txt" (set "DIAG_MSG=!DIAG_MSG! ✅ google list: Есть\n") else (set "DIAG_MSG=!DIAG_MSG! ⚠️ google list: Нет\n")

set "LAST_MSG=!DIAG_MSG!"
goto clear_with_msg

:: ========== ТЕСТЫ ==========
:run_tests
cls
echo ╔══════════════════════════════════════════════════════════════════════════╗
echo ║                         🧪 ЗАПУСК ТЕСТОВ 🧪                              ║
echo ╚══════════════════════════════════════════════════════════════════════════╝
echo.

if exist "%UTILS%test zapret.ps1" (
    powershell -NoProfile -ExecutionPolicy Bypass -File "%UTILS%test zapret.ps1"
    set "LAST_MSG=✅ Тесты завершены"
) else (
    set "LAST_MSG=❌ test zapret.ps1 не найден"
)
goto clear_with_msg

:: ========== ОБНОВИТЬ СПИСКИ ==========
:update_lists
cls
echo ╔══════════════════════════════════════════════════════════════════════════╗
echo ║                         📥 ОБНОВЛЕНИЕ СПИСКОВ 📥                         ║
echo ╚══════════════════════════════════════════════════════════════════════════╝
echo.

if exist "%~dp0service.bat" (
    call "%~dp0service.bat" admin
    set "LAST_MSG=✅ Списки обновлены"
) else (
    set "LAST_MSG=❌ service.bat не найден"
)
goto clear_with_msg

:: ========== ОЧИСТИТЬ КЭШ ==========
:clear_cache
cls
echo ╔══════════════════════════════════════════════════════════════════════════╗
echo ║                         🗑️ ОЧИСТКА КЭША 🗑️                               ║
echo ╚══════════════════════════════════════════════════════════════════════════╝
echo.

:: Очистка DNS кэша
ipconfig /flushdns >nul
set "CACHE_MSG=✅ DNS кэш очищен\n"

:: Очистка кэша Discord
if exist "%APPDATA%\discord\Cache" (
    rd /s /q "%APPDATA%\discord\Cache" 2>nul
    set "CACHE_MSG=!CACHE_MSG! ✅ Discord кэш очищен\n"
)

:: Очистка временных файлов
del /q /f "%TEMP%\*" 2>nul
set "CACHE_MSG=!CACHE_MSG! ✅ Временные файлы очищены\n"

set "LAST_MSG=!CACHE_MSG!"
goto clear_with_msg

:: ========== СТАТИСТИКА ==========
:statistics
cls
echo ╔══════════════════════════════════════════════════════════════════════════╗
echo ║                         📊 СТАТИСТИКА 📊                                 ║
echo ╚══════════════════════════════════════════════════════════════════════════╝
echo.

set "STAT_MSG="

:: Подсчет доменов
for /f %%i in ('type "%LISTS%list-google.txt" 2^>nul ^| find /c /v ""') do set "GOOGLE_COUNT=%%i"
for /f %%i in ('type "%LISTS%list-general.txt" 2^>nul ^| find /c /v ""') do set "GENERAL_COUNT=%%i"
for /f %%i in ('type "%LISTS%list-exclude.txt" 2^>nul ^| find /c /v ""') do set "EXCLUDE_COUNT=%%i"
for /f %%i in ('type "%LISTS%list-general-user.txt" 2^>nul ^| find /c /v ""') do set "USER_COUNT=%%i"

set "STAT_MSG=!STAT_MSG! 📋 Google список: !GOOGLE_COUNT! доменов\n"
set "STAT_MSG=!STAT_MSG! 📋 General список: !GENERAL_COUNT! доменов\n"
set "STAT_MSG=!STAT_MSG! 📋 Исключения: !EXCLUDE_COUNT! доменов\n"
set "STAT_MSG=!STAT_MSG! 📋 Пользовательские: !USER_COUNT! доменов\n\n"

:: Информация о процессе
tasklist | find "winws.exe" >nul
if !errorlevel! equ 0 (
    for /f "tokens=1,2,3,4,5" %%a in ('tasklist ^| find "winws.exe"') do (
        set "STAT_MSG=!STAT_MSG! ✅ winws.exe запущен: %%a %%b\n"
    )
) else (
    set "STAT_MSG=!STAT_MSG! ⚠️ winws.exe не запущен\n"
)

set "LAST_MSG=!STAT_MSG!"
goto clear_with_msg

:: ========== IPSET НАСТРОЙКИ ==========
:ipset_settings
cls
echo ╔══════════════════════════════════════════════════════════════════════════╗
echo ║                         🌐 IPSET НАСТРОЙКИ 🌐                            ║
echo ╚══════════════════════════════════════════════════════════════════════════╝
echo.
echo   Текущий режим: !IPSET_STATUS!
echo.
echo   [1] Включить IPSet
echo   [2] Отключить IPSet
echo   [3] Режим "Любой" (any)
echo   [4] 🔙 НАЗАД
echo.
set /p ipset_choice="   Выберите опцию: "

if "%ipset_choice%"=="1" (
    echo 203.0.113.113/32 > "%LISTS%ipset-all.txt"
    set "IPSET_STATUS=Включен"
    set "LAST_MSG=✅ IPSet включен"
    goto clear_with_msg
)
if "%ipset_choice%"=="2" (
    copy "%LISTS%ipset-all.txt" "%LISTS%ipset-all.bak" >nul 2>&1
    echo 203.0.113.113/32 > "%LISTS%ipset-all.txt"
    set "IPSET_STATUS=Отключен"
    set "LAST_MSG=✅ IPSet отключен"
    goto clear_with_msg
)
if "%ipset_choice%"=="3" (
    echo. > "%LISTS%ipset-all.txt"
    set "IPSET_STATUS=Любой"
    set "LAST_MSG=✅ IPSet режим: Любой"
    goto clear_with_msg
)
if "%ipset_choice%"=="4" goto menu
goto ipset_settings

:: ========== АВТО-ОБНОВЛЕНИЕ ==========
:auto_update_settings
cls
echo ╔══════════════════════════════════════════════════════════════════════════╗
echo ║                         🔄 АВТО-ОБНОВЛЕНИЕ 🔄                            ║
echo ╚══════════════════════════════════════════════════════════════════════════╝
echo.
echo   Текущий статус: !UPDATE_STATUS!
echo.
echo   [1] Включить авто-обновление
echo   [2] Отключить авто-обновление
echo   [3] 🔙 НАЗАД
echo.
set /p update_choice="   Выберите опцию: "

if "%update_choice%"=="1" (
    echo ENABLED > "%UTILS%check_updates.enabled"
    set "UPDATE_STATUS=Включено"
    set "LAST_MSG=✅ Авто-обновление включено"
    goto clear_with_msg
)
if "%update_choice%"=="2" (
    if exist "%UTILS%check_updates.enabled" del "%UTILS%check_updates.enabled"
    set "UPDATE_STATUS=Отключено"
    set "LAST_MSG=✅ Авто-обновление отключено"
    goto clear_with_msg
)
if "%update_choice%"=="3" goto menu
goto auto_update_settings

:: ========== ИГРОВОЙ РЕЖИМ ==========
:game_mode_settings
cls
echo ╔══════════════════════════════════════════════════════════════════════════╗
echo ║                         🎮 ИГРОВОЙ РЕЖИМ 🎮                              ║
echo ╚══════════════════════════════════════════════════════════════════════════╝
echo.
echo   Текущий статус: !GAME_FILTER_STATUS!
echo.
echo   [1] Включить (TCP + UDP)
echo   [2] Только TCP
echo   [3] Только UDP
echo   [4] Отключить
echo   [5] 🔙 НАЗАД
echo.
set /p game_choice="   Выберите опцию: "

if "%game_choice%"=="1" (
    echo all > "%UTILS%game_filter.enabled"
    set "GAME_FILTER_STATUS=TCP+UDP"
    set "GAME_MODE=1"
    set "LAST_MSG=✅ Игровой режим: TCP+UDP"
    goto clear_with_msg
)
if "%game_choice%"=="2" (
    echo tcp > "%UTILS%game_filter.enabled"
    set "GAME_FILTER_STATUS=Только TCP"
    set "GAME_MODE=1"
    set "LAST_MSG=✅ Игровой режим: Только TCP"
    goto clear_with_msg
)
if "%game_choice%"=="3" (
    echo udp > "%UTILS%game_filter.enabled"
    set "GAME_FILTER_STATUS=Только UDP"
    set "GAME_MODE=1"
    set "LAST_MSG=✅ Игровой режим: Только UDP"
    goto clear_with_msg
)
if "%game_choice%"=="4" (
    if exist "%UTILS%game_filter.enabled" del "%UTILS%game_filter.enabled"
    set "GAME_FILTER_STATUS=Отключен"
    set "GAME_MODE=0"
    set "LAST_MSG=✅ Игровой режим отключен"
    goto clear_with_msg
)
if "%game_choice%"=="5" goto menu
goto game_mode_settings

:: ========== DNS НАСТРОЙКИ ==========
:dns_settings
cls
echo ╔══════════════════════════════════════════════════════════════════════════╗
echo ║                         🌍 РЕЖИМ DNS 🌍                                  ║
echo ╚══════════════════════════════════════════════════════════════════════════╝
echo.
echo   Текущий режим: !DNS_MODE!
echo.
echo   [1] DNS-over-HTTPS
echo   [2] Обычный DNS
echo   [3] 🔙 НАЗАД
echo.
set /p dns_choice="   Выберите опцию: "

if "%dns_choice%"=="1" (
    set "DNS_MODE=DoH"
    set "DNS_MODE_FLAG=1"
    set "LAST_MSG=✅ Режим DNS: DoH"
    goto clear_with_msg
)
if "%dns_choice%"=="2" (
    set "DNS_MODE=Обычный"
    set "DNS_MODE_FLAG=0"
    set "LAST_MSG=✅ Режим DNS: Обычный"
    goto clear_with_msg
)
if "%dns_choice%"=="3" goto menu
goto dns_settings

:: ========== SSL/TLS НАСТРОЙКИ ==========
:ssl_settings
cls
echo ╔══════════════════════════════════════════════════════════════════════════╗
echo ║                         🔒 SSL/TLS НАСТРОЙКИ 🔒                          ║
echo ╚══════════════════════════════════════════════════════════════════════════╝
echo.
echo   Текущий режим: !SSL_MODE!
echo.
echo   [1] Google TLS (стабильный)
echo   [2] Max TLS (агрессивный)
echo   [3] 🔙 НАЗАД
echo.
set /p ssl_choice="   Выберите опцию: "

if "%ssl_choice%"=="1" (
    set "SSL_MODE=Google"
    set "SSL_MODE_FLAG=1"
    set "LAST_MSG=✅ SSL режим: Google"
    goto clear_with_msg
)
if "%ssl_choice%"=="2" (
    set "SSL_MODE=Max"
    set "SSL_MODE_FLAG=2"
    set "LAST_MSG=✅ SSL режим: Max"
    goto clear_with_msg
)
if "%ssl_choice%"=="3" goto menu
goto ssl_settings

:: ========== РЕЖИМ ПРОИЗВОДИТЕЛЬНОСТИ ==========
:performance_settings
cls
echo ╔══════════════════════════════════════════════════════════════════════════╗
echo ║                         ⚡ РЕЖИМ ПРОИЗВОДИТЕЛЬНОСТИ ⚡                   ║
echo ╚══════════════════════════════════════════════════════════════════════════╝
echo.
echo   Текущий режим: !PERF_MODE!
echo.
echo   [1] Максимальная производительность
echo   [2] Сбалансированный
echo   [3] Максимальная совместимость
echo   [4] 🔙 НАЗАД
echo.
set /p perf_choice="   Выберите опцию: "

if "%perf_choice%"=="1" (
    set "PERF_MODE=Максимальная"
    set "PERFORMANCE_MODE=1"
    set "LAST_MSG=✅ Режим: Максимальная производительность"
    goto clear_with_msg
)
if "%perf_choice%"=="2" (
    set "PERF_MODE=Сбалансированный"
    set "PERFORMANCE_MODE=0"
    set "LAST_MSG=✅ Режим: Сбалансированный"
    goto clear_with_msg
)
if "%perf_choice%"=="3" (
    set "PERF_MODE=Совместимость"
    set "PERFORMANCE_MODE=2"
    set "LAST_MSG=✅ Режим: Максимальная совместимость"
    goto clear_with_msg
)
if "%perf_choice%"=="4" goto menu
goto performance_settings

:: ========== АВТОЗАПУСК ЗАПРЕТА ==========
:autorun_settings
cls
echo ╔══════════════════════════════════════════════════════════════════════════╗
echo ║                         🔄 АВТОЗАПУСК ЗАПРЕТА 🔄                         ║
echo ╚══════════════════════════════════════════════════════════════════════════╝
echo.
echo   Текущий статус: !AUTORUN_STATUS!
echo.
echo   [1] Добавить в автозагрузку
echo   [2] Удалить из автозагрузки
echo   [3] 🔙 НАЗАД
echo.
set /p autorun_choice="   Выберите опцию: "

if "%autorun_choice%"=="1" (
    reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "ALL Zapret" /t REG_SZ /d "%~f0" /f >nul
    set "AUTORUN_STATUS=Включен"
    set "LAST_MSG=✅ Добавлено в автозагрузку"
    goto clear_with_msg
)
if "%autorun_choice%"=="2" (
    reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "ALL Zapret" /f >nul 2>&1
    set "AUTORUN_STATUS=Отключен"
    set "LAST_MSG=✅ Удалено из автозагрузки"
    goto clear_with_msg
)
if "%autorun_choice%"=="3" goto menu
goto autorun_settings

:: ========== ЗАГРУЗКА НАСТРОЕК ==========
:load_settings
:: Игровой фильтр
if exist "%UTILS%game_filter.enabled" (
    for /f "usebackq delims=" %%A in ("%UTILS%game_filter.enabled") do (
        if "%%A"=="all" set "GAME_FILTER_STATUS=TCP+UDP" & set "GAME_MODE=1"
        if "%%A"=="tcp" set "GAME_FILTER_STATUS=Только TCP" & set "GAME_MODE=1"
        if "%%A"=="udp" set "GAME_FILTER_STATUS=Только UDP" & set "GAME_MODE=1"
    )
) else (
    set "GAME_FILTER_STATUS=Отключен"
    set "GAME_MODE=0"
)

:: IPSet
if exist "%LISTS%ipset-all.txt" (
    for /f %%i in ('type "%LISTS%ipset-all.txt" 2^>nul ^| find /c /v ""') do set "lineCount=%%i"
    if !lineCount!==0 (
        set "IPSET_STATUS=Любой"
    ) else (
        findstr /R "^203\.0\.113\.113/32$" "%LISTS%ipset-all.txt" >nul
        if !errorlevel!==0 (
            set "IPSET_STATUS=Отключен"
        ) else (
            set "IPSET_STATUS=Включен"
        )
    )
) else (
    set "IPSET_STATUS=Не настроен"
)

:: Автообновление
if exist "%UTILS%check_updates.enabled" (
    set "UPDATE_STATUS=Включено"
) else (
    set "UPDATE_STATUS=Отключено"
)

:: Автозапуск
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "ALL Zapret" >nul 2>&1
if !errorlevel! equ 0 (
    set "AUTORUN_STATUS=Включен"
) else (
    set "AUTORUN_STATUS=Отключен"
)

:: DNS режим
set "DNS_MODE=Обычный"
set "DNS_MODE_FLAG=0"

:: SSL режим
set "SSL_MODE=Google"
set "SSL_MODE_FLAG=1"

:: Производительность
set "PERF_MODE=Сбалансированный"
set "PERFORMANCE_MODE=0"

goto :eof