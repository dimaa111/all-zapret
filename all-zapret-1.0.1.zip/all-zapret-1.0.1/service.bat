@echo off
chcp 65001 > nul
title ALL Zapret УНИВЕРСАЛЬНЫЙ v1.9.7

cd /d "%~dp0"

:: ========== ВЫЗОВ СЕРВИСНЫХ ФУНКЦИЙ ==========
call service.bat status_zapret
call service.bat check_updates
call service.bat load_game_filter
call service.bat load_user_lists
echo.

:: ========== ПЕРЕМЕННЫЕ ==========
set "BIN=%~dp0bin\"
set "LISTS=%~dp0lists\"
cd /d %BIN%

:: ========== ОСТАНОВКА СТАРЫХ ПРОЦЕССОВ ==========
taskkill /F /IM winws.exe >nul 2>&1
timeout /t 2 /nobreak >nul

:: ========== ЗАПУСК УНИВЕРСАЛЬНОГО ОБХОДА ==========
echo Запуск ALL Zapret Universal...
echo.

start "ALL Zapret" /min "%BIN%winws.exe" ^

:: --wf-tcp -- базовые порты + игровой фильтр
--wf-tcp=80,443,2053,2083,2087,2096,8443,%GameFilterTCP% ^
--wf-udp=443,19294-19344,50000-50100,%GameFilterUDP% ^

:: -- СТРАТЕГИЯ 1: UDP 443 (основная) + QUIC фейк
--filter-udp=443 --hostlist="%LISTS%list-general.txt" --hostlist="%LISTS%list-general-user.txt" --hostlist-exclude="%LISTS%list-exclude.txt" --hostlist-exclude="%LISTS%list-exclude-user.txt" --ipset-exclude="%LISTS%ipset-exclude.txt" --ipset-exclude="%LISTS%ipset-exclude-user.txt" --dpi-desync=fake --dpi-desync-repeats=11 --dpi-desync-fake-quic="%BIN%quic_initial_www_google_com.bin" --new ^

:: -- СТРАТЕГИЯ 2: UDP порты Discord (голос, стримы)
--filter-udp=19294-19344,50000-50100 --filter-l7=discord,stun --dpi-desync=fake --dpi-desync-repeats=6 --new ^

:: -- СТРАТЕГИЯ 3: TCP discord.media (мультисплит + фейк TLS)
--filter-tcp=2053,2083,2087,2096,8443 --hostlist-domains=discord.media --dpi-desync=fake,multisplit --dpi-desync-split-seqovl=681 --dpi-desync-split-pos=1 --dpi-desync-fooling=ts --dpi-desync-repeats=8 --dpi-desync-split-seqovl-pattern="%BIN%tls_clienthello_www_google_com.bin" --dpi-desync-fake-tls="%BIN%tls_clienthello_www_google_com.bin" --new ^

:: -- СТРАТЕГИЯ 4: Google/YouTube (ip-id=zero для защиты)
--filter-tcp=443 --hostlist="%LISTS%list-google.txt" --ip-id=zero --dpi-desync=fake,multisplit --dpi-desync-split-seqovl=681 --dpi-desync-split-pos=1 --dpi-desync-fooling=ts --dpi-desync-repeats=8 --dpi-desync-split-seqovl-pattern="%BIN%tls_clienthello_www_google_com.bin" --dpi-desync-fake-tls="%BIN%tls_clienthello_www_google_com.bin" --new ^

:: -- СТРАТЕГИЯ 5: TCP 80/443 (общий) с фейком от Max
--filter-tcp=80,443 --hostlist="%LISTS%list-general.txt" --hostlist="%LISTS%list-general-user.txt" --hostlist-exclude="%LISTS%list-exclude.txt" --hostlist-exclude="%LISTS%list-exclude-user.txt" --ipset-exclude="%LISTS%ipset-exclude.txt" --ipset-exclude="%LISTS%ipset-exclude-user.txt" --dpi-desync=fake,multisplit --dpi-desync-split-seqovl=664 --dpi-desync-split-pos=1 --dpi-desync-fooling=ts --dpi-desync-repeats=8 --dpi-desync-split-seqovl-pattern="%BIN%tls_clienthello_max_ru.bin" --dpi-desync-fake-tls="%BIN%stun.bin" --dpi-desync-fake-tls="%BIN%tls_clienthello_max_ru.bin" --dpi-desync-fake-http="%BIN%tls_clienthello_max_ru.bin" --new ^

:: -- СТРАТЕГИЯ 6: UDP 443 по IPset (для всех IP в списке)
--filter-udp=443 --ipset="%LISTS%ipset-all.txt" --hostlist-exclude="%LISTS%list-exclude.txt" --hostlist-exclude="%LISTS%list-exclude-user.txt" --ipset-exclude="%LISTS%ipset-exclude.txt" --ipset-exclude="%LISTS%ipset-exclude-user.txt" --dpi-desync=fake --dpi-desync-repeats=11 --dpi-desync-fake-quic="%BIN%quic_initial_www_google_com.bin" --new ^

:: -- СТРАТЕГИЯ 7: TCP 80/443/8443 по IPset
--filter-tcp=80,443,8443 --ipset="%LISTS%ipset-all.txt" --hostlist-exclude="%LISTS%list-exclude.txt" --hostlist-exclude="%LISTS%list-exclude-user.txt" --ipset-exclude="%LISTS%ipset-exclude.txt" --ipset-exclude="%LISTS%ipset-exclude-user.txt" --dpi-desync=fake,multisplit --dpi-desync-split-seqovl=664 --dpi-desync-split-pos=1 --dpi-desync-fooling=ts --dpi-desync-repeats=8 --dpi-desync-split-seqovl-pattern="%BIN%tls_clienthello_max_ru.bin" --dpi-desync-fake-tls="%BIN%stun.bin" --dpi-desync-fake-tls="%BIN%tls_clienthello_max_ru.bin" --dpi-desync-fake-http="%BIN%tls_clienthello_max_ru.bin" --new ^

:: -- СТРАТЕГИЯ 8: Игровой режим TCP (any-protocol для всех игр)
--filter-tcp=%GameFilterTCP% --ipset="%LISTS%ipset-all.txt" --ipset-exclude="%LISTS%ipset-exclude.txt" --ipset-exclude="%LISTS%ipset-exclude-user.txt" --dpi-desync=fake,multisplit --dpi-desync-any-protocol=1 --dpi-desync-cutoff=n4 --dpi-desync-split-seqovl=664 --dpi-desync-split-pos=1 --dpi-desync-fooling=ts --dpi-desync-repeats=8 --dpi-desync-split-seqovl-pattern="%BIN%tls_clienthello_max_ru.bin" --dpi-desync-fake-tls="%BIN%stun.bin" --dpi-desync-fake-tls="%BIN%tls_clienthello_max_ru.bin" --dpi-desync-fake-http="%BIN%tls_clienthello_max_ru.bin" --new ^

:: -- СТРАТЕГИЯ 9: Игровой режим UDP (fake для неизвестных UDP)
--filter-udp=%GameFilterUDP% --ipset="%LISTS%ipset-all.txt" --ipset-exclude="%LISTS%ipset-exclude.txt" --ipset-exclude="%LISTS%ipset-exclude-user.txt" --dpi-desync=fake --dpi-desync-repeats=10 --dpi-desync-any-protocol=1 --dpi-desync-fake-unknown-udp="%BIN%quic_initial_www_google_com.bin" --dpi-desync-cutoff=n4

:: ========== ПРОВЕРКА ЗАПУСКА ==========
timeout /t 3 /nobreak >nul
tasklist | find /I "winws.exe" >nul
if %errorLevel% equ 0 (
    echo.
    echo ✅ ALL Zapret Universal успешно запущен!
    echo.
    echo Поддерживаемые сервисы:
    echo - Discord (голос, видео, стримы)
    echo - YouTube (видео, сайт)
    echo - Roblox (игра, сайт)
    echo - Telegram (сайт, приложение)
    echo - Twitch (стримы)
    echo - VK / Mail.ru
    echo - Steam / Epic Games
    echo - Rutube
    echo - Pinterest / Instagram
    echo - Любые игры (через игровой фильтр)
) else (
    echo.
    echo ❌ Ошибка запуска!
    echo Проверьте наличие файлов в папке bin/
)

:: ========== СОХРАНЕНИЕ РЕЗУЛЬТАТА ==========
if exist "%UTILS%test results" (
    echo %date% %time% - Запуск ALL Zapret > "%UTILS%test results\last_run.txt"
    tasklist | find "winws.exe" >> "%UTILS%test results\last_run.txt"
)

echo.
echo Нажмите любую клавишу для выхода...
pause >nul
exit